@echo off
echo Starting AI Medical Platform...
pip install -r requirements.txt
streamlit run app.py
pause