#!/bin/bash
echo "Starting AI Medical Platform..."

# 安装依赖
pip install -r requirements.txt

# 启动 streamlit
streamlit run app.py

# 执行完暂停（防止窗口直接关闭）
read -p "Press Enter to exit..."