```
# 🏥 智慧医疗多 Agent 协作平台 (Ollama 版)

本项目基于 Ollama 部署，采用 **Router-Worker (分诊-接诊)** 多 Agent 架构。

## 🚀 快速开始

1. **安装环境**:
   确保已安装 Python 3.8+，然后在终端执行：
   ```bash
   pip install -r requirements.txt
```

1. **准备模型**: 确保 Ollama 已在后台运行，并拉取模型：

   Bash

   ```
   ollama pull qwen3.5
   # 或者选择 DeepSeek
   ollama pull deepseek-r1:7b
   ```

2. **启动程序**:

   - **Windows**: 双击 `start_platform.bat`
   - **通用**: 执行 `streamlit run app.py`

## 🤖 Agent 协作逻辑

1. **分诊护士 (Router)**: 接收用户主诉，识别病因意图，并以 JSON 格式输出匹配的科室。
2. **专科医生 (Worker)**: 根据分诊结果，加载特定的专家系统提示词进行深度问诊。

```
---

### 3. `app.py`
这是整个平台的核心业务代码，包含了多 Agent 分诊与接诊的逻辑。请保存为 `app.py`：

```python
import streamlit as st
import ollama
import json

# ==========================================
# 1. 页面基本配置
# ==========================================
st.set_page_config(page_title="AI 智慧医疗平台", page_icon="🏥", layout="wide")

# 自定义 CSS 样式
st.markdown("""
<style>
    .main { background-color: #f5f7f9; }
    .stStatus { border-radius: 10px; border: 1px solid #e0e0e0; }
</style>
""", unsafe_allow_html=True)

# 侧边栏
with st.sidebar:
    st.title("🏥 医疗指挥中心")
    model_option = st.selectbox(
        "选择底层模型:",
        ("qwen3.5", "deepseek-r1:7b", "qwen2.5:14b"),
        index=0
    )
    st.info("架构：多 Agent 协作系统\n角色：分诊护士 + 专科专家")
    if st.button("🗑️ 清空问诊记录"):
        st.session_state.messages = []
        st.rerun()

# ==========================================
# 2. Agent 角色定义
# ==========================================
TRIAGE_PROMPT = """
你是一所大型综合医院的资深分诊护士。你的任务是分析患者的主诉，并将其分类。
可选科室：[内科, 外科, 心理科, 营养科]。
请严格按 JSON 格式输出：{"department": "科室名", "reason": "分诊理由"}。
不要输出任何其他多余文字。
"""

SPECIALIST_PROMPTS = {
    "内科": "你是一位资深内科专家，擅长通过病理逻辑分析病因。请用专业严谨的态度给出建议。",
    "外科": "你是一位外科专家，处理伤口、骨骼、肌肉问题。请重点强调急救措施和手术必要性评估。",
    "心理科": "你是一位资深心理咨询师。请用极度共情、温暖的语气进行心理疏导和压力缓解建议。",
    "营养科": "你是一位临床营养师。请根据患者情况给出详细的饮食结构调整和营养补充建议。"
}

# 初始化会话状态
if "messages" not in st.session_state:
    st.session_state.messages = []

# ==========================================
# 3. UI 交互界面
# ==========================================
st.title("🏥 智慧医疗多 Agent 协作平台")
st.caption("基于本地 Ollama 算力 | 隐私安全 | 专家级诊疗建议")

# 渲染历史对话
for message in st.session_state.messages:
    if message["role"] != "system":
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

# 输入逻辑
if prompt := st.chat_input("请描述您的不适症状或需求..."):
    # 记录用户输入
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        # --- 第一步：Agent 1 分诊协作 ---
        with st.status("👩‍⚕️ 分诊台正在评估...", expanded=True) as status:
            try:
                triage_res = ollama.chat(
                    model=model_option,
                    messages=[{"role": "system", "content": TRIAGE_PROMPT}, {"role": "user", "content": prompt}],
                    format="json"
                )
                data = json.loads(triage_res['message']['content'])
                dept = data.get("department", "内科")
                reason = data.get("reason", "常规分析")
                st.write(f"✅ 分诊结果：**{dept}**")
                st.write(f"💡 评估依据：{reason}")
                status.update(label=f"分诊完成：已转接至{dept}专家", state="complete", expanded=False)
            except Exception:
                dept = "内科"
                st.write("⚠️ 分诊异常，已默认转接全科内科。")
                status.update(label="分诊完成 (自动兼容模式)", state="complete")

        # --- 第二步：Agent 2 专家诊疗 ---
        response_placeholder = st.empty()
        full_response = f"**【{dept}专家接诊】**\n\n"
        
        try:
            specialist_prompt = SPECIALIST_PROMPTS.get(dept, SPECIALIST_PROMPTS["内科"])
            # 构建上下文：专家提示词 + 用户最新输入
            msgs = [{"role": "system", "content": specialist_prompt}]
            msgs.extend(st.session_state.messages[-3:]) # 保持最近三轮记忆
            
            stream = ollama.chat(model=model_option, messages=msgs, stream=True)
            for chunk in stream:
                content = chunk['message']['content']
                full_response += content
                response_placeholder.markdown(full_response + " ▌")
            
            disclaimer = """\n\n---\n> **免责声明**：本 AI 平台建议仅供参考。医疗诊断具有复杂性，请务必以线下医院面诊结果为准。"""
            full_response += disclaimer
            response_placeholder.markdown(full_response)
            
            st.session_state.messages.append({"role": "assistant", "content": full_response})
        except Exception as e:
            st.error(f"连接专家 Agent 失败: {str(e)}")
```

------

### 4. `start_platform.bat`

这是为 Windows 环境准备的一键启动脚本（Mac/Linux 用户可忽略或将其写为 `.sh` 脚本）。请保存为 `start_platform.bat`：

DOS

```
@echo off
echo Starting AI Medical Platform...
pip install -r requirements.txt
streamlit run app.py
pause
```